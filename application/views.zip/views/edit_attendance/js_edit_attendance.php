
<!--right slidebar-->
<script src="<?php echo $base_url ?>public/js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $base_url ?>public/js/dynamic_table_init_officer.js"></script>

<script src="<?php echo $base_url ?>public/js/form-validation-script_add_user.js"></script>


</body>
</html>
