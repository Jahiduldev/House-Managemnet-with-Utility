<!--main content start-->
<section id="main-content">
    <section class="wrapper">
      
        
       <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Dashboard
						</header>
                    <div class="panel-body">

                         <div class="row">
                           
                        </div>
<br>
                        <div class="adv-table">
                            <table class="display table table-bordered" id="hidden-table-info">
                                <thead>
                               
                                </thead>
                                <tbody>
                            



                                      

								
                                </tbody>
                            </table>

                        </div>

                    </div>
                </section>
            </div>
        </div>


    </section>
</section>
<!--main content end-->