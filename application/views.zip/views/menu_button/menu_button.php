<?php date_default_timezone_set("Asia/Thimbu"); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper site-min-height">
        <div class="row">
	
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                       
                    </header>
                    <div class="panel-body" style="margin-top:50px;">
                    

                       <div class="col-lg-6" >
					   <a href="<?php echo site_url('submit_attendance');  ?>"><button type="button"  class="btn btn-info "> Attendance</button></a>
					   </div>
					    <div class="col-lg-6">
						   <a href="<?php echo site_url('shop_wise_report');  ?>"><button type="button"  class="btn btn-info "> Attendance Report</button></a>
                       </div>

                    </div>
                </section>
            </div>
        </div>


    </section>
</section>
<!--main content end-->


