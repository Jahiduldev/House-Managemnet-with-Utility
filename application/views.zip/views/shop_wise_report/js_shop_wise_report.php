
<!--dynamic table initialization -->
<script src="<?php echo $base_url ?>public/js/dynamic_table_init_shop_wise_report.js"></script>
<script src="<?php echo $base_url ?>public/js/form-validation-script_shop_wise_report.js"></script>



</body>
</html>
