<!--dynamic table initialization -->
<script src="<?php echo $base_url ?>public/js/dynamic_table_init_officer.js"></script>



<script>


       function addModal(sid){
		   
        var arr=sid.split('-');
        var id=arr[0];
	    var name_house=arr[1];
		

	        $.ajax({
                type: "Post",
                url: "<?php echo site_url('all_room/getData');  ?>",
                data: {'id':id} ,
                success: function(data) {  
				var ob=JSON.parse(data);
				var id=ob[0].id;
			
				var room_name=ob[0].room_name;
				var room_code=ob[0].room_code;
				
			    var notes=ob[0].notes;
			
				
			
				console.log(data);
				  $("#id").val(id);
                  $("#name_house").val(name_house);
                  $("#room_name").val(room_name);
                  $("#room_code").val(room_code);	
               			  
				  $("#notes").val(notes);	
			
				  			 
                }
            });
	   
	   
     $("#addModal").modal();
    }

</script>



</body>
</html>
