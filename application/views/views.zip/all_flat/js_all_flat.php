<!--dynamic table initialization -->
<script src="<?php echo $base_url ?>public/js/dynamic_table_init_officer.js"></script>



<script>


       function addModal(sid){
		   
        var arr=sid.split('-');
        var id=arr[0];
	    var name_house=arr[1];
		

	        $.ajax({
                type: "Post",
                url: "<?php echo site_url('all_flat/getData');  ?>",
                data: {'id':id} ,
                success: function(data) {  
				var ob=JSON.parse(data);
				var id=ob[0].id;
			
				var flat_name=ob[0].flat_name;
				var flat_code=ob[0].flat_code;
				
			    var notes=ob[0].notes;
			
				
			
				console.log(data);
				  $("#id").val(id);
                  $("#name_house").val(name_house);
                  $("#flat_name").val(flat_name);
                  $("#flat_code").val(flat_code);	
               			  
				  $("#notes").val(notes);	
			
				  			 
                }
            });
	   
	   
     $("#addModal").modal();
    }

</script>



</body>
</html>
